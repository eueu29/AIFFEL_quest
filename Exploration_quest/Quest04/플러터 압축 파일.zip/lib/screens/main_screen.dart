/*
* This file is part of the Artiluxio application (see https://github.com/pguijas/artiluxio).
* Copyright (C) 2023 Pedro Guijas | Elena Sánchez | Angel Miguélez
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

import 'package:flutter/material.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/app_bloc.dart';
import '../widgets/flotting_button.dart';
import '../widgets/last_inferences.dart';
import '../widgets/model_selector.dart';
import 'help_screen.dart';
import 'image_screen.dart';
import 'inference_screen.dart';

class MainScreen extends StatelessWidget {
  // Atributes
  final String title = "Style Transfer Demo";
  final double imgSize = 125.0;
  ValueNotifier<bool> isDialOpen = ValueNotifier(false);

  MainScreen({super.key}) {
    lastInferencesFuture = readLastInferences();
  }

  // Read last inferences
  late Future<List<String>> lastInferencesFuture;
  Future<List<String>> readLastInferences() async {
    Directory dir = await getApplicationDocumentsDirectory();
    Directory inferenceDir = Directory("${dir.path}/inferences/");
    Stream<FileSystemEntity> fileStream = inferenceDir.list();

    List<String> lastInferences = [];
    await for (FileSystemEntity file in fileStream) {
      lastInferences.add(file.path);
    }

    return lastInferences;
  }

  // goInference Callback
  void goInference(BuildContext context, String imgPath) {
    AppBloc appBloc = BlocProvider.of<AppBloc>(context);
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => InferenceScreen(imgPath, appBloc)),
    );
  }

  // goToSettings Callback
  void goToSettings(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const HelpScreen()),
    );
  }

  // itemBuilder Generator (last inferences)
  Widget itemBuilder(BuildContext context, int i, List<String> images) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => ImageScreen(path: images[i])),
        );
      }, // Image tapped
      splashColor: Colors.black87,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(2),
        child: Ink.image(
          image: FileImage(File(images[i])),
          height: imgSize,
          width: imgSize,
          fit: BoxFit.cover,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    bool isDarkMode =
        MediaQuery.of(context).platformBrightness == Brightness.dark;
    List<String> models = BlocProvider.of<AppBloc>(context).models;

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Image.asset(
          'assets/logo.png',
          fit: BoxFit.contain,
          //height: ,
        ),
        backgroundColor: isDarkMode ? Colors.black : Colors.white,
        elevation: 0.0,
        actions: [
          IconButton(
            icon: const Icon(Icons.help_outline),
            color: Colors.black,
            //isDarkMode ? Colors.black : Colors.white,
            onPressed: () {
              goToSettings(context);
            },
          ),
        ],
      ),

      // Body
      body: BlocBuilder<AppBloc, AppBlocState>(
        builder: (context, state) {
          return SingleChildScrollView(
            child: Column(
              children: [
                ///////////////////
                /// Hello! Text
                ///////////////////
                Container(
                  margin: const EdgeInsets.only(left: 20.0, top: 20.0),
                  child: const Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      "이유진, 김동규의 트랜스퍼입니다!",
                      style: TextStyle(
                        fontSize: 50,
                        fontFamily: "Roboto",
                      ),
                    ),
                  ),
                ),

                ////////////////////////
                /// Model Selectior
                ///////////////////////
                ModelSelector(
                  isDarkMode: isDarkMode,
                  models: models,
                  selectedModel: state.modelIndex,
                  onChanged: (i) => BlocProvider.of<AppBloc>(context)
                      .add(ChangedModelEvent(i)),
                ),

                ////////////////////////
                /// Last Inferences
                ///////////////////////
                FutureBuilder<List<String>>(
                  future: lastInferencesFuture,
                  builder: (BuildContext context,
                      AsyncSnapshot<List<String>> snapshot) {
                    List<Widget> children;
                    if (!snapshot.hasData || snapshot.data!.isEmpty) {
                      children = <Widget>[
                        const Text("이전 추론 결과가 없습니다."),
                      ];
                    } else {
                      children = <Widget>[
                        LastInferences(
                          imgSize: imgSize,
                          itemBuilder: itemBuilder,
                          images: snapshot.data!,
                        ),
                      ];
                    }
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: children,
                      ),
                    );
                  },
                ),
              ],
            ),
          );
        },
      ),

      //////////////////////////////
      // Centered Floating Button
      //////////////////////////////
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: FloattingButton(
        isDialOpen: isDialOpen,
        onCamera: () {
          BlocProvider.of<AppBloc>(context)
              .getInputImage(true, context, goInference);
          isDialOpen.value = false;
        },
        onGallery: () {
          BlocProvider.of<AppBloc>(context)
              .getInputImage(false, context, goInference);
          isDialOpen.value = false;
        },
      ),
    );
  }
}
