import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:http/http.dart';

import '../helper/global.dart';

class APIs {
  // get answer from chat gpt
  static Future<void> getAnswer(String question) async {
    final res = await post(
      Uri.parse('https://api.openai.com/v1/chat/completions'),

      //headers
      headers: {
        HttpHeaders.contentTypeHeader: 'application/json',
        HttpHeaders.authorizationHeader: 'Bearer $apiKey'
      },

      //body
      body: jsonEncode(
        {
          "model": "gpt-3.5-turbo",
          "messages": [
            {"role": "user", "content": question},
          ]
        },
      ),
    );

    log('res: ${res.body}');
  }
}
