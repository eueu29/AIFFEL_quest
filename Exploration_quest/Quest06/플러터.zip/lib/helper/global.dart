import 'package:flutter/material.dart';

// app name
const appName = 'Ai Assistant';

// media query to store size of device screen
late Size mq;

// chat gpt api key
const apiKey = '123';
