class Onboard {
  final String title, subtitle, lottie;

  Onboard({
    required this.title,
    required this.subtitle,
    required this.lottie,
  });
}
