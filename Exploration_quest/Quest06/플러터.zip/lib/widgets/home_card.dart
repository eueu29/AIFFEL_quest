import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:lottie/lottie.dart';

import '../helper/global.dart';
import '../models/home_type.dart';

class HomeCard extends StatelessWidget {
  final HomeType homeType;
  const HomeCard({super.key, required this.homeType});

  @override
  Widget build(BuildContext context) {
    Animate.restartOnHotReload = true;

    return Card(
      margin: EdgeInsets.only(
        bottom: mq.height * .02,
      ),
      color: Colors.blue.withOpacity(.2),
      elevation: 0,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(
          Radius.circular(
            20,
          ),
        ),
      ),
      child: homeType.leftAlign
          ? Row(
              children: [
                // lottie
                Container(
                  width: homeType.width,
                  padding: homeType.padding,
                  child: Lottie.asset(
                    'assets/lottie/${homeType.lottie}',
                  ),
                ),

                const Spacer(),

                //title
                Text(
                  homeType.title,
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 18,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 1,
                  ),
                ),
                const Spacer(flex: 2),
              ],
            )
          : Row(
              children: [
                const Spacer(flex: 2),

                //title
                Text(
                  homeType.title,
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 18,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 1,
                  ),
                ),
                const Spacer(),

                // lottie
                Container(
                  width: homeType.width,
                  padding: homeType.padding,
                  child: Lottie.asset(
                    'assets/lottie/${homeType.lottie}',
                  ),
                ),
              ],
            ),
    ).animate().fade(
          duration: 1.seconds,
          curve: Curves.easeIn,
        );
  }
}
